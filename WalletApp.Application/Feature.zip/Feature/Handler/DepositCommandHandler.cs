﻿using MediatR;
using WalletApp.Application.Feature.Command;
using WalletApp.Application.Feature.DTO;
using WalletApp.Application.Services.Repositories.EntitysRepository;
using WalletApp.Domain.Abstraction.Repositories;
using WalletApp.Domain.Base;
using WalletApp.Domain.Enums;

namespace WalletApp.Application.Feature.Handler;

public class DepositCommandHandler : IRequestHandler<DepositCommand, ServiceResponse<TransactionDTO>>
{
    private readonly IWalletRepository _walletRepository;
    private readonly ITransactionRepository _transactionRepository;

    public DepositCommandHandler(IWalletRepository walletRepository, ITransactionRepository transactionRepository)
    {
        _walletRepository = walletRepository;
        _transactionRepository = transactionRepository;
    }

    public async Task<ServiceResponse<TransactionDTO>> Handle(DepositCommand request, CancellationToken cancellationToken)
    {
        // Validation
        if (request.Amount <= 0)
            return ServiceResponse<TransactionDTO>.Fail("Amount must be greater than zero.");

        var wallet = await _walletRepository.GetByIdAsync(request.WalletId);
        if (wallet == null)
            return ServiceResponse<TransactionDTO>.Fail("Wallet not found.");

        if (wallet.UserId != request.RequestedBy)
            return ServiceResponse<TransactionDTO>.Fail("You do not own this wallet.");

        // İşlem
        var transaction = new Transaction
        {
            WalletId = request.WalletId,
            Amount = request.Amount,
            Type = TransactionType.Deposit,
            Description = request.Description ?? "Deposit"
        };

        await _transactionRepository.AddAsync(transaction);

        var dto = new TransactionDTO
        {
            WalletId = transaction.WalletId,
            Amount = transaction.Amount,
            Type = transaction.Type,
            Description = transaction.Description
        };

        return ServiceResponse<TransactionDTO>.Ok(dto, "Deposit successful.");
    }
}
