﻿
namespace WalletApp.Application.Feature.DTO;
    public class CreateBankAccountRequestDTO
{
    public Guid WalletId { get; set; }
    public string Bilgiler { get; set; }
}
