﻿namespace WalletApp.Application.Feature.DTO
{
    public class UserResponseDTO
    {
        public string Email { get; set; }
        public string Password { get; set; }
    }
}
