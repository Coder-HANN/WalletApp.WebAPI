﻿using MediatR;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using WalletApp.Application.Feature.DTO;

namespace WalletApp.WebAPI.Controllers;

[Authorize]
[ApiController]
[Route("api/[controller]")]
public class BankAccountController : ControllerBase
{
    private readonly IMediator _mediator;

    public BankAccountController(IMediator mediator)
    {
        _mediator = mediator;
    }

    private int GetUserId() => int.Parse(User.FindFirst("userId")?.Value ?? throw new UnauthorizedAccessException());

    [HttpPost("add")]
    public async Task<IActionResult> AddBankAccount([FromBody] CreateBankAccountRequest request)
    {
        return await AddBankAccount(request);
    }

    public IActionResult HandleResponse<T>(ServiceResponse<T> response)
    {   // await yok ona bak
        return HandleResponse(response);
    }
}

public class CreateBankAccountRequest
{
    public Guid WalletId { get; set; }
    public string Bilgiler { get; set; }
}
